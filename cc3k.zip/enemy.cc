#include "enemy.h"
#include <cmath>
#include <ctime>
#include <utility>

using namespace std;

Enemy::Enemy(): Character{}, isEnemy{true} {}

Enemy::~Enemy(){}

int Enemy::attack(Character * whom){
  int damage = 0;
  if((this->getRace() == "Merchant") && (whom->getState() == false)) return 0;
  srand(time(NULL));
  int i = rand() % 2;
	if(i == 1) { // else enemy misses this attack
		damage += whom->beAttacked(this);
	}
  if((this->getRace() == "Elf") && (whom->getRace() != "Drow")){
    srand(clock());
    int j = rand() % 2;
  	if(j == 1){
  		damage += whom->beAttacked(this);
  	}
  }
  return damage;
}

int Enemy::beAttacked(Character * who){
  if(this->getRace() == "Merchant") who->getState() = true;
  isEnemy = true;
	int damage = ceil(who->getAtk() * 100 / (100 + this->getDef()));
	if(this->getHp() > damage){
	  this->getHp() -= damage;
	} else {
	  this->getHp() = 0;
	}
  if(this->getHp() == 0) {
    this->dropGold(who);
  }
  return damage;
}

void Enemy::dropGold(Character *who) {
  if(who->getRace() == "Goblin") {
    who->getGold() += 5;
  }
  if(this->getRace() == "Human") {
    who->getGold() += 4;
  }
  if(this->getRace() == "Merchant") {
    who->getGold() += 6;
  }
}

bool Enemy::isE() {return isEnemy;}
