#include "enemy.h"
#include "merchant.h"
#include <string>
using namespace std;

Merchant::Merchant(): Enemy{} {
	isEnemy = false;
	getHp() = 30;
	getAtk() = 70;
	getDef() = 5;
	getRace() = "Merchant";
};

Merchant::~Merchant(){}
