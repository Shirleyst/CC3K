#include "character.h"
#include <iostream>

using namespace std;

Character::Character(): race{""}, hp{0}, atk{0}, def{0}, gold{0},
permission{true}, state{false} {}

//Character::Character(int hp, int atk, int def): hp{hp}, atk{atk}, def{def} {}

int &Character::getGold() {return gold;}

void Character::printInfo() {return;}

int &Character::getDef() {return def;}

int &Character::getAtk() {return atk;}

int &Character::getHp() {return hp;}

int &Character::getMax() {return hp;}

bool &Character::getPermiss() {return permission;}

bool &Character::getState() {return state;}

bool Character::isE() {return false;}

string &Character::getRace() {return race;}

string Character::setApply() {return "";}

int Character::attack(Character *whom) {return 0;}

int Character::beAttacked(Character *who) {return 0;}

bool Character::isDead() {
  return (hp < 1) ;
}

Character::~Character() {}

ostream &operator<<(ostream &out, Character &c) {
  if((c.getRace() == "Shade") || (c.getRace() == "Drow")
    || (c.getRace() == "Vampire") || (c.getRace() == "Troll")
    || (c.getRace() == "Goblin")) {
    cout << "@";
  }
  if(c.getRace() == "Human") cout << "H";
  if(c.getRace() == "Dwarf") cout << "W";
  if(c.getRace() == "Elf") cout << "E";
  if(c.getRace() == "Orcs") cout << "O";
  if(c.getRace() == "Merchant") cout << "M";
  if(c.getRace() == "Dragon") cout << "D";
  if(c.getRace() == "Halfling") cout << "L";
  if(c.getRace() == "Potion") cout << "P";
  if(c.getRace() == "Gold") cout << "G";
  return out;
}
