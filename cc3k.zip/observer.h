#ifndef _OBSERVER_H_
#define _OBSERVER_H_
#include <string>
class Subject;
class Cell;
class Floor;

class Observer {
 public:
   //virtual void notify()=0;
  virtual std::string notify(Floor &f, std::pair<int,int> coo, Subject &whoNotified) = 0;
  												  // pass the Cell that called
                                                  // the notify method
  virtual ~Observer() = default;
};
#endif
