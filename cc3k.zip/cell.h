#ifndef CELL_H
#define CELL_H
#include <utility>
#include <iostream>
#include "subject.h"
#include "observer.h"

class Character;
class Floor;

class Cell : public Subject, public Observer{
  char content;
  int chamber;
  std::pair <int, int> coord;
  Character *cha;
public:
  Cell(char c, int row, int col);
  char &getContent();
  int &getRow();
  int &getCol();
  int &getChamber();
  bool sameCell(std::pair <int, int> c);
  void createPotion(Character *c, int type);
  void createGold(Character *c, int type);
  bool isPlayerOrEnemy();

  Character *&getChar();
  virtual void printChar();
  std::string notify(Floor &f, std::pair<int,int> coo, Subject &whoNotified) override;
  ~Cell();

  friend std::ostream &operator<<(std::ostream &out, Cell &c);
};

#endif
