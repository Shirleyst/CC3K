#ifndef CONTROL_H
#define CONTROL_H

class game;

class Control {
  game* g;
  std::string &c;
public:
  Control(game *g);
  void command(std::string &comm);
  ~Control();
  //void cin_command();
};

#endif
