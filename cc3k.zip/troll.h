#include "player.h"

class Troll : public Player {
public:
  Troll();
  ~Troll();
};
