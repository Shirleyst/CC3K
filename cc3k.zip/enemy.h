#ifndef __ENEMY_H__
#define __ENEMY_H__

#include "character.h"

class Enemy: public Character{
protected:
  bool isEnemy = true;
public:
  Enemy();
  //void becomeEnemy();
  //int & getGold() override;
  //void printInfo() override;
  int attack(Character* whom) override;
  int beAttacked(Character* who) override;
  void dropGold(Character *who);
  bool isE() override;
  virtual ~Enemy() = 0;
};


#endif
