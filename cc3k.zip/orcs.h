#ifndef __ORCS_H__
#define __ORCS_H__
#include "enemy.h"

class Orcs: public Enemy{
	public:
		Orcs();
		~Orcs();
};


#endif
