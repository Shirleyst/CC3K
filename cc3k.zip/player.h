#ifndef PLAYER_H
#define PLAYER_H
#include "character.h"
#include <vector>

class Player : public Character {
protected:
  int maxHP;
public:
  Player();
  int &getMax() override;
  int attack(Character* whom) override;
  int beAttacked(Character* who) override;
  virtual ~Player() = 0;
  void printInfo() override;
};

#endif
