#include "game.h"
#include "floor.h"
#include "cell.h"
#include "character.h"
#include <iostream>
#include <sstream>
#include <vector>

using namespace std;

Game::Game(): command{}, floors{nullptr}, base{},  emptys{},
race{""}, numFloors{5}, currentFloor{0} {
  cout << "You have opened the game for CC3k :)" << endl;
}

void Game::generate(int hp) {
  if(hp == 0) {
    cout << "Please pick a race for PC(enter any of the below):" << endl;
    cout << "d(Drow), g(Goblin), s(Shade), t(Troll), v(Vampire)." << endl;
    string racePC;
    if(cin >> racePC) {
      if(racePC == "d") race = "Drow";
      if(racePC == "g") race = "Goblin";
      if(racePC == "s") race = "Shade";
      if(racePC == "t") race = "Troll";
      if(racePC == "v") race = "Vampire";
      this->race = race;
      if(race == "") {
        cout << "No matching race, exit:(" << endl;
        return;
      }
    } else {
      cout << "Exit without begin :(" << endl;
      return;
    }
  }
  // generate floors
  //floors[currentFloor]=Floor(*this, numFloors)
  floors->generate(hp, this->race);
  cout << *floors;
  cout << "Player character has spawned." << endl;
}

vector<Cell> Game::getEmp() { return emptys;}

vector <vector <Cell>> Game::getBase() {return base;}

void Game::nextlevel(int hp) {
  currentFloor++;
  //cout << "QQQQQQQQQQQQQ"<<currentFloor<<endl;
  if(currentFloor != 5) {
    cout << currentFloor;
    floors->floor_clear();
    // floors->getMap() = getBase();
    // floors->getcurrEmp().resize(getBase().size());
    // vector <pair<int, int>> sub{getBase().size()};
    // for(int i = 0; i < 5; i++) {
    //   floors->getcurrEmp().push_back(sub);
    // }
    // int u = getEmp().size();
    // for(int j = 0; j < u; j++) {
    //   int index = getEmp()[j].getChamber();
    //   int r = getEmp()[j].getRow();
    //   int c = getEmp()[j].getCol();
    //   floors->getcurrEmp()[index - 1].emplace_back(make_pair(r, c));
    // }
    floors->generate(hp, race);
  } else {
    isWin();
  }
}

bool Game::isWin() {
  if(currentFloor != 4) return false;
  cout << "Win!!!!!!" << endl;
  return true;
}

bool Game::isLost() {
  return floors->isLost();
}

void Game::stop() {
  floors->stop();
  cout << (*this);
  cout << "Switch between Stop/Move mode." << endl;
}

void Game::move(string &comm) {
  command = comm;
  string pInfo = "";
  floors->move(comm, pInfo);
  cout << (*this);
  cout << pInfo;
  //floors[currentFloor].printSurround();
  cout << endl;
}

void Game::use(string &comm) {
  string info = "";
  command = comm;
  floors->use(comm, info);
  cout << (*this);
  cout << info;
  //floors[currentFloor].printSurround();
  cout << endl;
}

void Game::attack(string &comm) {
  string pInfo = "";
  command = comm;
  floors->attack(comm, pInfo);
  cout << (*this);
  cout << pInfo;
  //floors[currentFloor].printSurround();
  cout << endl;
}

Game::~Game() {}

void Game::checkChamber() {
  int currChamber = 1;
  int r_l = base.size();
  int c_l = base[0].size();
  int u = emptys.size();
  for(int i = 0; i < u; i++) {
    if(emptys[i].getChamber() == 0) {
      emptys[i].getChamber() = currChamber;
      checkSurround(emptys[i], currChamber, r_l, c_l);
      currChamber++;
    }
  }
  for(int j = 0; j < u; j++) {
    int r = emptys[j].getRow();
    int c = emptys[j].getCol();
    base[r][c].getChamber() = emptys[j].getChamber();
  }
}

void Game::checkSurround(Cell &middle, int chamber, int r_l, int c_l) {
  int r = middle.getRow();
  int c = middle.getCol();
  for(int x = max(0, r - 1); x <= min(r + 1, r_l); x++) {
    for(int y = max(0, c - 1); y <= min(c + 1, c_l); y++) {
      if(x != r || y != c) {
        int u = emptys.size();
        for(int i = 0; i < u; i++) {
          if((emptys[i].sameCell(make_pair(x, y)))
            && ((emptys[i]).getChamber() == 0)) {
            (emptys[i]).getChamber() = chamber;
            checkSurround(emptys[i], chamber, r_l, c_l);
          }
        }
      }
    }
  }
}


istream &operator>>(istream &in, Game &g) {
  string l;
  char c;
  int row = 0;
  while(getline(in, l)) {
    vector<Cell> sub;
    (g.base).push_back(sub);
    int coloum = 0;
    stringstream ss{l};
    while(ss >> noskipws >> c) {
      Cell cell{c, row, coloum};
      if(c == '.') {
        g.emptys.push_back(cell);
      }
      g.base[row].push_back(cell);
      coloum++;
    }
    ss.str(string());
    row++;
  }
  g.checkChamber();
  //for(int i = 0; i < g.numFloors; i++) {
    g.floors = new Floor{g, 0};
  //}
  return in;
}

ostream &operator<<(ostream &out, Game &g) {
  if(g.isLost()){
    cout << "Lost" << endl;
    return out;
  }
  //int l = g.currentFloor;
  cout << (*g.floors);
  return out;
}
