#ifndef DECORATOR_H
#define DECORATOR_H
#include "character.h"

class Decorator: public Character {
protected:
  Character *component;
public:
  Decorator(Character *component);
  std::string setApply() override;
  virtual ~Decorator();
};

#endif
