#include "cell.h"
#include "character.h"
#include "item.h"
#include "floor.h"

using namespace std;

Cell::Cell(char c, int row, int col): content{c}, chamber{0},
coord{std::make_pair(row, col)}, cha{nullptr} {}

char &Cell::getContent() {
  return content;
}

int &Cell::getRow() {
  return coord.first;
}

int &Cell::getCol(){
  return coord.second;
}

int &Cell::getChamber() {
  return chamber;
}

Character *&Cell::getChar() {
  return cha;
}

bool Cell::sameCell(pair <int, int> c) {
  return ((getRow() == c.first) && (getCol() == c.second));
}

void Cell::printChar() {
  return;
}

string Cell::notify(Floor &f, pair<int,int> coo, Subject &s) {
  Cell & theCell = f.getMap()[coo.first][coo.second];
  string info = "";
  if(theCell.getContent()=='D'){
    // #ifdef DEBUG
    // cout <<"notifying the dragon"<<endl;
    // #endif
    Character * theDragon = theCell.getChar();
    if(isPlayerOrEnemy()){
      // cout<<"Dragon is attacking"<<endl;
      this->getChar()->beAttacked(theDragon);
      // #ifdef DEBUG
      // cout <<this->getChar()->getRace()<< " HP is "<<getChar()->getHp()<<endl;
      // cout << "dragon attack "<< n <<endl;
      // #endif
      if(getChar()->getHp() == 0) {
        int x = this->getRow();
        int y = this->getCol();
        getContent() = '.';
        getChar() = nullptr;
        // #ifdef DEBUG
        // cout << "has set nullptr"<<endl;
        // #endif
        int chamber = getChamber() - 1;
        f.getcurrEmp()[chamber].emplace_back(make_pair(x, y));
        vector <pair<int, int>> & enemys = f.getEnemys();
        int n = enemys.size();
        for(int i = 0; i < n; i++) {
           if(enemys[i].first == x && enemys[i].second == y) {
             enemys.erase(enemys.begin() + i);
           }
         }
        vector <vector <Cell>>& map = f.getMap();
        int ax = f.getPlayers().first;
        int ay = f.getPlayers().second;
        map[ax][ay].dettach(this);
        // int size = map[ax][ay].getOb().size();
        // for(int i = 0; i < size; i++) {
        //   if(map[ax][ay].getOb()[i] == (&map[x][y])) {
        //     map[ax][ay].getOb().erase(map[ax][ay].getOb().begin() + i);
        //   }
        // }
      }
    }
    // info += "dragon deals" + to_string(n) + " damage to " + 
    // this->getChar()->getRace();
    // return info;
  }
  if(this->getContent() == 'D'){
    pair<int, int> dragonCoord = make_pair(getRow(), getCol());
    this->notifyObservers(f, dragonCoord, *this);
    return "";
  }
  int n = f.enemys_random_move(coord.first, coord.second);
  if(n > 0) {
    info += this->getChar()->getRace() + " deals " + to_string(n) +
    " damage to PC.";
  }
  return info;
}

bool Cell::isPlayerOrEnemy(){
  if(getChar() != nullptr){
    if((getChar()->getRace()!="Potion")&&(getContent()!='G')){return true;}
  }
  return false;
}

void Cell::createPotion(Character *c, int type) {
  content = 'P';
  cha = new Item{c, "Potion", type};
}

void Cell::createGold(Character *c, int type) {
  content = 'G';
  cha = new Item{c, "Gold", type};
}

Cell::~Cell() { //if(cha != nullptr) delete cha;
}

ostream &operator<<(ostream &out, Cell &c) {
  if(c.cha == nullptr) {
    cout << c.content;
  } else {
    cout << (*c.cha);
  }
  return out;
}
