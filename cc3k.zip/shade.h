#include "player.h"

class Shade : public Player {
public:
  Shade();
  ~Shade();
  //void attack(Character * whom) override;
  //void beAtacked(Character * who) override;
};
