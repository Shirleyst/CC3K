// #include "decorator.h"

// class Character;

// class Gold: public Decorator {
//  public:
//   Gold();
//  	Gold(Character *c, std::string type);
// };
