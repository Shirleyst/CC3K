#include "player.h"

class Drow : public Player {
public:
  Drow();
  ~Drow();
  //void attack(Character * whom) override;
  //void beAtacked(Character * who) override;
};
