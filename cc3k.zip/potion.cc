// #include "potion.h"
// #include "cell.h"

// using namespace std;

// Potion::Potion(): Decorator{nullptr} {this->getRace() = "Potion";}

// Potion::Potion(Character *c, int type): Decorator{c} 
//  {this->getRace() = "Potion";
//   this->getGold() = 0;
//   if(type == 0) this->getHp() = 10;
//   if(type == 1) this->getAtk() = 5;
//   if(type == 2) this->getDef() = 5;
//   if(type == 3) this->getHp() = -10;
//   if(type == 4) this->getAtk() = -5;
//   if(type == 5) this->getDef() = -5;
// }

