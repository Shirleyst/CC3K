#ifndef __HUMAN_H__
#define __HUMAN_H__
#include <utility>
class Character;

class Human: public Enemy{
	Human();
	public:
		void attack(Character * Whom) override;
		void beAttacked(Character * who) override;
		Human(std::pair<int, int>);
		gold * die() override;

}


#endif

