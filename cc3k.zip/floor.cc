#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <algorithm>
#include "cell.h"
#include "floor.h"
#include "shade.h"
#include "character.h"
#include "dragon.h"
#include "drow.h"
#include "vampire.h"
#include "goblin.h"
#include "troll.h"
#include "human.h"
#include "dwarf.h"
#include "elf.h"
#include "halfling.h"
#include "orcs.h"
#include "merchant.h"
#include "game.h"

using namespace std;

// void Floor::track_dragon(){
//   int u = dragons.size();
//   for(int i = 0; i < u; i++){
//     int x = dragons[i].first;
//     int y = dragons[i].second;
//     map[x][y].notifyObservers(*this,make_pair(x,y), map[x][y]);
//   }
// }
void Floor::floor_clear(){
  int u = map.size();
  for(int i = 0; i < u; i++){
    int v = map.at(i).size();
    for(int j = 0; j < v; j++){delete map[i][j].getChar();}
    map.at(i).clear();
  }
  int p = theGame.getBase()[0].size();
  for(int i = 0; i < u; i++){
    for(int j = 0; j < p; j++){
      map[i].push_back(theGame.getBase()[i][j]);
    }
  }

  enemys.clear();
  dragons.clear();

  u = curremp.size();
  for(int i = 0; i < u; i++){curremp.at(i).clear();}

  u = theGame.getEmp().size();
  for(int j = 0; j < u; j++) {
    int index = theGame.getEmp()[j].getChamber();
    int r = theGame.getEmp()[j].getRow();
    int c = theGame.getEmp()[j].getCol();
    curremp[index - 1].emplace_back(make_pair(r, c));
  }
}


vector <pair<int, int>>& Floor::getEnemys(){
  return enemys;
}

Floor::Floor(Game &g, int f): theGame{g}, map{g.getBase()},
curremp{vector<vector <pair<int, int>>>{g.getBase().size()}},
enemys{vector <pair<int, int>>{g.getBase().size()}},
players{std::make_pair(0, 0)}, hoard{std::make_pair(0, 0)},
numPotion{10}, numGold{10}, numEnemy{20}, floor{f}, dragon{true}, command{},
m{true} {
  vector <pair<int, int>> sub{g.getBase().size()};
  for(int i = 0; i < 5; i++) {
    curremp.push_back(sub);
  }
  int u = g.getEmp().size();
  for(int j = 0; j < u; j++) {
    int index = g.getEmp()[j].getChamber();
    int r = g.getEmp()[j].getRow();
    int c = g.getEmp()[j].getCol();
    curremp[index - 1].emplace_back(make_pair(r, c));
  }
  cout << "New floor has been generated." << endl;
}

vector <vector <Cell>> &Floor::getMap() {return map;}

vector <vector <pair<int, int>>> &Floor::getcurrEmp() {
  return curremp;
}

void Floor::generate(int hp, string race) {
  int chamber = 0;
  this->generatePlayer(hp, race, chamber);
  map[players.first][players.second - 1].getContent() = '\\';
  //this->generateSW(chamber);
  //this->generatePotion(numPotion);
  //this->generateGold(numGold);
  //this->generateEnemy(numEnemy);
}

void Floor::generatePlayer(int hp, string race, int &chamber) {
  srand((unsigned)time(NULL));
  int cham = rand() % 5; // 0-4
  chamber = cham + 1;
  int total = curremp[cham].size();
  srand(clock());
  int ran = rand() % total;
  int r = curremp[cham][ran].first;
  int c = curremp[cham][ran].second;
  if(race == "Shade") { map[r][c].getChar() = new Shade{}; }
  if(race == "Drow") { map[r][c].getChar() = new Drow{}; }
  if(race == "Vampire") { map[r][c].getChar() = new Vampire(); }
  if(race == "Goblin") { map[r][c].getChar() = new Goblin(); }
  if(race == "Troll") { map[r][c].getChar() = new Troll(); }
  if(hp != 0) map[r][c].getChar()->getHp() = hp;
  map[r][c].getChar()->getHp() = 10000;
  players = make_pair(r, c);
  for(auto it = curremp[chamber - 1].begin();
    it != curremp[chamber - 1].end(); it++) {
    if((r == it->first) && (c == it->second)) {
      it = curremp[chamber - 1].erase(it);
    }
  }
}

void Floor::generateSW(int chamber) {
  int newcham = chamber - 1;
  int total = 0;
  while(((chamber - 1) == newcham) || (total == 0)) {
    srand(clock());
    newcham = rand() % 5; // 0-4
    total = curremp[newcham].size();
  }
  srand(clock());
  int index = rand() % total;
  int r = curremp[newcham][index].first;
  int c = curremp[newcham][index].second;
  map[r][c].getContent() = '\\';
  for(auto it = curremp[newcham].begin();
    it != curremp[newcham].end(); it++) {
    if((r == it->first) && (c == it->second)) {
      it = curremp[newcham].erase(it);
    }
  }
}

void Floor::generatePotion(int n) {
  int x = players.first;
  int y = players.second;
  for(int i = 0; i < 100; i++) {
    srand(clock());
    int chamber = rand() % 5; // 0-4
    srand(clock());
    int type = rand() % 6; // 0-5
    srand(clock());
    int index = rand() % curremp[chamber].size();
    int r = curremp[chamber][index].first;
    int c = curremp[chamber][index].second;
    map[r][c].createPotion(map[x][y].getChar(), type);
    curremp[chamber].erase(curremp[chamber].begin() + index);
  }
}

void Floor::generateGold(int n) {
  bool canPutDragon = true;
  int type;
  int x = players.first;
  int y = players.second;
  for(int i = 0; i < n; i++) {
    srand(clock());
    int chamber = rand() % 5; // 0-4
    if(canPutDragon) {
      srand(clock());
      type = rand() % 8; // 0-7
    } else {
      srand(clock());
      type = rand() % 7; // 0-7
    }
    srand(clock());
    int size = curremp[chamber].size();
    int index = rand() % size;
    int r = curremp[chamber][index].first;
    int c = curremp[chamber][index].second;
    map[r][c].getContent() = 'G';
    if(type != 7) {
      map[r][c].createGold(map[x][y].getChar(), type);
    }
    curremp[chamber].erase(curremp[chamber].begin() + index);
    if(type == 7) {
      hoard.first = r;
      hoard.second = c;
      canPutDragon = false;
      vector<pair<int, int>> dargonPos;
      int u = curremp[chamber].size();
      for(int j = 0; j < u; j++){
        int x = curremp[chamber][j].first;
        int y = curremp[chamber][j].second;
        if((r - 1 <= x && x <= r + 1) && (c - 1 <= y && y <= c + 1)
          && (x != r && y != c)) {
          dargonPos.emplace_back(make_pair(x, y));
        }
      }
      srand(clock());
      int v = dargonPos.size();
      int pos = rand() % v;
      generateDragon(dargonPos[pos].first, dargonPos[pos].second);
      for(int i = r-1; i <= r+1; i++){
        for(int j = c-1; j <= c+1; j++){
          if(!((i==dargonPos[pos].first)&&(j==dargonPos[pos].second))){
            map[dargonPos[pos].first][dargonPos[pos].second].attach(&map[i][j]);
          }
        }
      }
    }
  }
}

void Floor::generateDragon(int x, int y) {
  int newcham = map[x][y].getChamber();
  map[x][y].getContent() = 'D';
  map[x][y].getChar() = new Dragon{};
  for(auto it = curremp[newcham - 1].begin();
    it != curremp[newcham - 1].end(); it++) {
    if((x == it->first) && (y == it->second)) {
      it = curremp[newcham - 1].erase(it);
    }
  }
  enemys.emplace_back(make_pair(x, y));
  dragons.emplace_back(make_pair(x, y));
  for(int i = x-1; i <= x+1; i++){
    for(int j = y-1; j <= y+1; j++){
      if((i != x) && (j != y)){
        map[x][y].attach(&map[i][j]);
      }
    }
  }
}

void Floor::generateEnemy(int n) {
  for(int i = 0; i < n; i++) {
    srand(clock());
    int chamber = rand() % 5; // 0-4
    srand(clock());
    int type = rand() % 18; // 0-17
    srand(clock());
    if(curremp[chamber].size() != 0) {
      int u = curremp[chamber].size();
      int index = rand() % u;
      int r = curremp[chamber][index].first;
      int c = curremp[chamber][index].second;
      if(0 <= type && type <= 3){
        map[r][c].getContent() = 'H';
        map[r][c].getChar() = new Human{};
      }
      else if(4 <= type && type <= 6){
        map[r][c].getContent() = 'W';
        map[r][c].getChar() = new Dwarf{};
      }
      else if(7 <= type && type <= 11){
        map[r][c].getContent() = 'L';
        map[r][c].getChar() = new Halfling{};
      }
      else if(12 <= type && type <= 13){
        map[r][c].getContent() = 'E';
        map[r][c].getChar() = new Elf{};
      }
      else if(14 <= type && type <= 15){
        map[r][c].getContent() = 'O';
        map[r][c].getChar() = new Orcs{};
      }
      else {
        map[r][c].getContent() = 'M';
        map[r][c].getChar() = new Merchant{};
      }
      enemys.emplace_back(make_pair(r, c));
      curremp[chamber].erase(curremp[chamber].begin() + index);
      map[players.first][players.second].attach(&map[r][c]);
    }
  }
}

void Floor::stop() {
  if(m) {
    m = false;
  } else {
    m = true;
  }
}

int Floor::enemys_random_move(int x, int y) {
  int d = 0;
  if(map[x][y].getChar() == nullptr) return 0;
  if(enemy_should_attack(x, y, d)) return d;
  if((m) && (map[x][y].getChar() != nullptr)) {
    if(map[x][y].getChar()->getRace() == "Dragon") {
      return 0;
    } else {
      int chamber = map[x][y].getChamber();
      if(chamber == 0) return 0;
      vector<pair<int, int>> pos;
      int u = curremp[chamber - 1].size();
      for(int i = 0; i < u; i++){
        int px = curremp[chamber - 1][i].first;
        int py = curremp[chamber - 1][i].second;
        if((px - 1 <= x && x <= px + 1) && (py - 1 <= y && y <= py + 1)
          && (x != px && y != py)) {
          pos.emplace_back(make_pair(px, py));
        }
      }
      srand(clock());
      if(pos.size() != 0) {
        int index = rand() % pos.size();
        int newx = pos[index].first;
        int newy = pos[index].second;
        curremp[chamber - 1].emplace_back(make_pair(x, y));
        int u = curremp[chamber - 1].size();
        for(int j = 0; j < u; j++) {
          int r = curremp[chamber - 1][j].first;
          int c = curremp[chamber - 1][j].second;
          if(r == newx && c == newy) {
            curremp[chamber - 1].erase(curremp[chamber - 1].begin() + j);
          }
        }
        map[newx][newy].getChar() = map[x][y].getChar();
        map[x][y].getChar() = nullptr;
        std::swap(map[newx][newy].getContent(), map[x][y].getContent());
        int q = enemys.size();
        for(int k = 0; k < q; k++) {
          if(enemys[k].first == x && enemys[k].second == y) {
            enemys.erase(enemys.begin() + k);
          }
        }
        enemys.emplace_back(make_pair(newx, newy));
      }
    }
  }
  return 0;
}

bool Floor::enemy_should_attack(int r, int c, int &d){
  int playerR = players.first;
  int playerC = players.second;
  if((map[r][c].getChar()->getRace() == "Merchant") &&
     (map[playerR][playerC].getChar()->getState() == false)) {
    return false;
  }
  if(((playerR > r - 2) && (playerR < r + 2)) &&
     ((playerC > c - 2) && (playerC < c + 2))) {
    // if within the radius
    if(map[r][c].getChar() != nullptr) {
      d = map[r][c].getChar()->attack(map[playerR][playerC].getChar());
    }
    return true;
  }
  return false;
}

// void Floor::enemy_die(){
//   int u = enemys.size();
//   vector<pair<int,int>> to_earse{};
//   for(int i = 0; i < u; i++){
//     Cell & theCell = map[enemys.at(i).first][enemys.at(i).second];
//     int chamber = theCell.getChamber();
//     Character * theEnemy = theCell.getChar();
//     if(theEnemy->isDead()){
//       cout <<"DIEEEEEEE!!!!!" << endl;
//       delete theCell.getChar();
//       theCell.getChar() = nullptr;
//       theCell.getContent() = '.';
//       map[players.first][players.second].dettach(&theCell);
//       pair<int,int> dead_enemy = make_pair(enemys.at(i).first, enemys.at(i).second);
//       curremp[chamber].push_back(dead_enemy);
//       to_earse.push_back(dead_enemy);
//     }
//   }
//   int v = to_earse.size();
//   for(int i = 0; i < v; i++){
//     pair<int,int> dead_enemy = to_earse.at(i);
//     enemys.erase(std::remove(enemys.begin(), enemys.end(), dead_enemy), enemys.end());
//   }
// }

void Floor::walk(int &ax, int &ay, int x, int y) {
  if((map[ax][ay].getChar() == nullptr) || (map[x][y].getContent() == '|')
     || (map[x][y].getContent() == '-')) {
    return;
  }
  if((this->map[x][y].getContent() == '.') ||
     (this->map[x][y].getContent() == '+') ||
     (this->map[x][y].getContent() == '#') ||
     (((x == hoard.first) && (y == hoard.second)) && (dragon == true))) {
    std::swap(this->map[x][y].getChar(), this->map[ax][ay].getChar());
    int chamber = map[x][y].getChamber();
    if((chamber != 0) && (this->map[x][y].getContent() != 'G')) {
      int u = curremp[chamber - 1].size();
      for(int i = 0; i < u; i++) {
        int r = curremp[chamber - 1][i].first;
        int c = curremp[chamber - 1][i].second;
        if(r == x && c == y) {
          curremp[chamber - 1].erase(curremp[chamber - 1].begin() + i);
        }
      }
    }
    int c = map[ax][ay].getChamber();
    if(c != 0) curremp[c - 1].emplace_back(make_pair(ax, ay));
    ax = x;
    ay = y;
    players = make_pair(x, y);
  } else if(this->map[x][y].getContent() == 'G') {
    if(x == hoard.first && y == hoard.second && (dragon == false)) {
      this->map[x][y].getContent() = '.';
      std::swap(this->map[x][y].getChar(), this->map[ax][ay].getChar());
      this->map[x][y].getChar()->getGold() += 6;
    } else {
      this->map[x][y].getContent() = '.';
      this->map[x][y].getChar()->setApply();
      this->map[x][y].getChar() = this->map[ax][ay].getChar();
      this->map[ax][ay].getChar() = nullptr;
    }
    int chamber = map[x][y].getChamber() - 1;
    int v = curremp[chamber].size();
    for(int i = 0; i < v; i++) {
      int r = curremp[chamber][i].first;
      int c = curremp[chamber][i].second;
      if(r == x && c == y) {
        curremp[chamber].erase(curremp[chamber].begin() + i);
      }
    }
    int c = map[ax][ay].getChamber();
    if(c != 0) curremp[c - 1].emplace_back(make_pair(ax, ay));
    ax = x;
    ay = y;
    players = make_pair(ax, ay);
  }
  if(this->map[x][y].getContent() == '\\') {
    int x = players.first;
    int y = players.second;
    int hp = map[x][y].getChar()->getHp();
    floor++;
    this->theGame.nextlevel(hp);
  }
}

string Floor::drink(int x, int y) {
  string name = "";
  if(this->map[x][y].getChar() == nullptr) return "nothing";
  if(this->map[x][y].getContent() == 'P') {
    this->map[x][y].getContent() = '.';
    name += this->map[x][y].getChar()->setApply();
    this->map[x][y].getChar() = nullptr;
    int chamber = map[x][y].getChamber() - 1;
    curremp[chamber].emplace_back(make_pair(x, y));
    return name;
  } else {
    return "nothing";
  }
}

void Floor::use(string &comm, string &info) {
  string name;
  int ax = players.first;
  int ay = players.second;
  if(command == "so") {
    name += this->drink(ax + 1, ay);
  }
  if(command == "no") {
    name += this->drink(ax - 1, ay);
  }
  if(command == "ea") {
    name += this->drink(ax, ay + 1);
  }
  if(command == "we") {
    name += this->drink(ax, ay - 1);
  }
  if(command == "se") {
    name += this->drink(ax + 1, ay + 1);
  }
  if(command == "sw") {
    name += this->drink(ax + 1, ay - 1);
  }
  if(command == "ne") {
    name += this->drink(ax - 1, ay + 1);
  }
  if(command == "nw") {
    name += this->drink(ax - 1, ay - 1);
  }
  if(map[ax][ay].getChar()->getHp() > map[ax][ay].getChar()->getMax()) {
    map[ax][ay].getChar()->getHp() = map[ax][ay].getChar()->getMax();
  }
  if(name != "") {
    info += "PC uses " + name;
  } else {
    info += "PC do not know that direction(invalid direction)";
  }
  info += printSurround();
  info += map[ax][ay].notifyObservers(*this,make_pair(ax,ay), map[ax][ay]);
  map[ax][ay].clearOb();
  int u = enemys.size();
  for(int i = 0; i < u; i++) {
    map[ax][ay].attach(&map[enemys[i].first][enemys[i].second]);
  }
  if(map[ax][ay].getChar()->getRace() == "Troll") {
    map[ax][ay].getChar()->getHp() = min(map[ax][ay].getChar()->getMax(),
      map[ax][ay].getChar()->getHp() + 5);
  }
}

void Floor::move(string &comm, string &info) {
  //track_dragon();
  command = comm;
  int &ax = players.first;
  int &ay = players.second;
  int x = ax;
  int y = ay;
  cout << x << " " << y;
  if(command == "so") {
    this->walk(ax, ay, ax + 1, ay);
  }
  if(command == "no") {
    this->walk(ax, ay, ax - 1, ay);
  }
  if(command == "ea") {
    this->walk(ax, ay, ax, ay + 1);
  }
  if(command == "we") {
    this->walk(ax, ay, ax, ay - 1);
  }
  if(command == "se") {
    this->walk(ax, ay, ax + 1, ay + 1);
  }
  if(command == "sw") {
    this->walk(ax, ay, ax + 1, ay - 1);
  }
  if(command == "ne") {
    this->walk(ax, ay, ax - 1, ay + 1);
  }
  if(command == "nw") {
    this->walk(ax, ay, ax - 1, ay - 1);
  }
  cout << ax << " " << ay;
  string dir = "";
  if(comm == "no") dir = "North";
  if(comm == "ea") dir = "East";
  if(comm == "so") dir = "South";
  if(comm == "we") dir = "West";
  if(comm == "ne") dir = "North-East";
  if(comm == "nw") dir = "North-West";
  if(comm == "se") dir = "South-East";
  if(comm == "sw") dir = "South-West";
  if((x != ax) || (y != ay)) {
    info = info + "PC moves to " + dir;
  } else if(dir != ""){
    info = info + "PC cannot move to " + dir;
  } else {
    info = info + "PC do not know that direction(invalid direction)";
  }
  info += printSurround();
  info += map[x][y].notifyObservers(*this,make_pair(x,y), map[x][y]);
  map[x][y].clearOb();
  int u = enemys.size();
  for(int i = 0; i < u; i++) {
    map[ax][ay].attach(&map[enemys[i].first][enemys[i].second]);
  }
  if(map[ax][ay].getChar()->getRace() == "Troll") {
    map[ax][ay].getChar()->getHp() = min(map[ax][ay].getChar()->getMax(),
      map[ax][ay].getChar()->getHp() + 5);
  }
}

int Floor::hurt(int ax, int ay, int x, int y) {
  int damage = 0;
  // if there is an enemy in that direction
  if(map[x][y].getChar() != nullptr) {
    damage = map[ax][ay].getChar()->attack(map[x][y].getChar());
  }
  return damage;
}

void Floor::attack(string &comm, string &info) {
  //track_dragon();
  command = comm;
  int ax = players.first;
  int ay = players.second;
  int x, y;
  string enemy = "";
  if(command == "so") {
    x = ax + 1;
    y = ay;
  }
  if(command == "no") {
    x = ax - 1;
    y = ay;
  }
  if(command == "ea") {
    x = ax;
    y = ay + 1;
  }
  if(command == "we") {
    x = ax;
    y = ay - 1;
  }
  if(command == "se") {
    x = ax + 1;
    y = ay + 1;
  }
  if(command == "sw") {
    x = ax + 1;
    y = ay - 1;
  }
  if(command == "ne") {
    x = ax - 1;
    y = ay + 1;
  }
  if(command == "nw") {
    x = ax - 1;
    y = ay - 1;
  }
  int damage = this->hurt(ax, ay, x, y);
  if(damage > 0) {
    string enemy = map[x][y].getChar()->getRace();
    int h = map[x][y].getChar()->getHp();
    info = " PC deals " + to_string(damage) + " damge to " + enemy;
    info += "(" + to_string(h) + " HP)";
    if(map[x][y].getChar()->getHp() == 0) {
      if(map[x][y].getChar()->getRace() == "Dragon") {
        dragon = false;
        map[hoard.first][hoard.second].getChar()->getPermiss() = true;
      }
      this->map[x][y].getContent() = '.';
      this->map[x][y].getChar() = nullptr;
      int chamber = map[x][y].getChamber() - 1;
      curremp[chamber].emplace_back(make_pair(x, y));
      int n = enemys.size();
      for(int i = 0; i < n; i++) {
        if(enemys[i].first == x && enemys[i].second == y) {
          enemys.erase(enemys.begin() + i);
        }
      }
      int size = map[ax][ay].getOb().size();
      for(int i = 0; i < size; i++) {
        if(map[ax][ay].getOb()[i] == (&map[x][y])) {
          map[ax][ay].getOb().erase(map[ax][ay].getOb().begin() + i);
        }
      }
    }
  } else {
    info += "PC does nothing";
  }
  info += printSurround();
  info += map[ax][ay].notifyObservers(*this,make_pair(x,y), map[x][y]);
  map[ax][ay].clearOb();
  int u = enemys.size();
  for(int i = 0; i < u; i++) {
    map[ax][ay].attach(&map[enemys[i].first][enemys[i].second]);
  }
  if(map[ax][ay].getChar()->getRace() == "Troll") {
    map[ax][ay].getChar()->getHp() = min(map[ax][ay].getChar()->getMax(),
      map[ax][ay].getChar()->getHp() + 5);
  }
}

Floor::~Floor() {}

bool Floor::isLost() {
  return map[players.first][players.second].getChar()->isDead();
}

void Floor::printFirst() {
  int r = players.first;
  int c = players.second;
  string line = "Race: " + map[r][c].getChar()->getRace();
  line = line + " Gold: " + to_string(map[r][c].getChar()->getGold());
  int curr = floor + 1;
  string floor = "Floor " + to_string(curr) + " ";
  cout << line;
  int u = map[0].size();
  int v = line.length();
  int w = floor.length();
  for(int i = 0;
      i < u - v - w - 1; i++) {
    cout << " ";
  }
  cout << floor << endl;
}

string Floor::printSurround() {
  string info = "";
  for(int r = players.first - 1; r <= players.first + 1; r++) {
    for(int c = players.second - 1; c <= players.second + 1; c++) {
      if(!((r == players.first) && (c == players.second))) {
        if(map[r][c].getContent() == 'G') {
          info += " and sees some Gold";
        } else if (map[r][c].getContent() == 'P') {
          info += " and sees an unknown Potion";
        } else if (map[r][c].getChar() != nullptr) {
          info += " and sees a " + map[r][c].getChar()->getRace();
        }
      }
    }
  }
  info += ".";
  return info;
}

ostream &operator<<(ostream &out, Floor &f) {
  int u = f.map.size();
  //cout << "MAP Total Row = "<< u<<endl;
  for(int i = 0; i < u; i++) {
    int v = (f.map[i]).size();
    //cout << "MAP Total COL = "<< v<<endl;
    for(int j = 0; j < v; j++) {
      cout << f.map[i][j];
    }
    cout << endl;
  }
  f.printFirst();
  int r = f.players.first;
  int c = f.players.second;
  f.map[r][c].getChar()->printInfo();
  return out;
}

pair<int, int> &Floor::getPlayers(){
  return players;
}

// Floor& operator = (const Floor & other){
//   Floor tmp = other;
//   swap(tmp);
//   return *this;
// }
