#include "human.h"
#include "Character.h"
#include <utility>
#include <cstdlib>
#include <ctime>
#include <string>
#include "gold.h"
using namespace std;

void Human::attack(Character * whom){
	int i = srand(time(NULL)) % 2;
	if(i == 1){
		whom -> beAttacked(this);
	}
}

void Human::beAttacked(Character * who){
	hp -= ceil((100/(100 + this.det))* who->getAtk());
}


Human::Human(pair<int, int> coord){
	this->coord = coord;
	hp = 140;
	atk = 20;
	def = 20;
	race = "Human";
}

gold * die(){
	gold * g = new gold((*this));
	return g;
}
