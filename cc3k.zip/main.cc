#include "game.h"
#include <fstream>
#include <iostream>

using namespace std;

int main() {
  Game g;
  cout << "Please choose an map(enter name below):" << endl;
  string file;
  if(cin >> file) {
    ifstream iff{file};
    if(iff) {
      iff >> g;
    } else {
      cout << "You entered an invalid map, exit the game:(" << endl;
      return 0;
    }
  } else {
    cout << "You entered an invalid name, exit the game:(" << endl;
    return 0;
  }
  g.generate();
  string s;
  while(cin >> s) {
    if(g.isLost()){
      cout << "Lost!" << endl;
      break;
    }
    if(g.isWin()) break;
    if(s == "u") {
      if(cin >> s) {
        g.use(s);
        if(g.isLost()) return 0;
      }
    } else if(s == "a") {
      if(cin >> s) {
        g.attack(s);
        if(g.isLost()) return 0;
      }
    } else if(s == "q") {
      cout << "Exit" << endl;
      return 0;
    } else if(s == "f") {
      g.stop();
    } else {
    	g.move(s);
      if(g.isLost()) return 0;
    }
    //if(g.isWin()) break;
  }
  return 0;
}
