#ifndef _SUBJECT_H_
#define _SUBJECT_H_
#include <string>
#include <vector>
#include <string>
class Observer;
class Floor;

class Subject {
  std::vector<Observer*> observers;
 public:
  void attach(Observer *o);
  void dettach(Observer *o);
  std::string notifyObservers(Floor &f, std::pair<int,int> coo, Subject &);
  std::vector<Observer*> &getOb();
  void clearOb();
  virtual ~Subject() = 0;
};

#endif
