#ifndef FLOOR_H
#define FLOOR_H
#include <vector>
#include <utility>
//#include "game.h"
#include "cell.h"

class Character;
class Game;

class Floor {
  Game& theGame;
  std::vector <std::vector <Cell>> map;
  std::vector <std::vector <std::pair<int, int>>> curremp;
  std::vector <std::pair<int, int>> enemys;
  std::pair<int, int> players;
  std::pair<int, int> hoard;
  std::vector <std::pair<int, int>> dragons;
  int numPotion;
  int numGold;
  int numEnemy;
  int floor;
  bool dragon;
  std::string command;
  bool m;
public:
  void floor_clear();
  std::vector <std::pair<int, int>>& getEnemys();
  std::pair<int, int> &getPlayers();
  Floor(Game &g, int f);
  bool isLost() ;
  void move(std::string &comm, std::string &info);
  void walk(int &ax, int &ay, int x, int y);
  void use(std::string &comm, std::string &info);
  std::string drink(int x, int y);
  void attack(std::string &comm, std::string &info);
  int hurt(int ax, int ay, int x, int y);
  void stop() ;
  std::vector <std::vector <Cell>> &getMap();
  std::vector <std::vector <std::pair<int, int>>> &getcurrEmp();
  void generate(int hp,std::string race);
  void generatePlayer(int hp, std::string race, int &chamber);
  void generateSW(int chamber);
  void generateEnemy(int n);
  void generateDragon(int x, int y);
  void generatePotion(int n);
  void generateGold(int n);
  int enemys_random_move(int x, int y);
  bool enemy_should_attack(int x, int y, int &d);

  void enemy_die();

  void printFirst();
  std::string printSurround();
  virtual ~Floor();


  // void enemy_move(Cell & theEnemy, int newR, int newC);
  // void enemys_random_move(Cell & theEnemy);
  // void enemy_should_attack(Cell & theEnemy);
  // void enemy_action();

  friend std::ostream &operator<<(std::ostream &out, Floor &f);
};

#endif
