#include "goblin.h"
#include <cmath>

Goblin::Goblin():Player{} {
  this->getRace() = "Goblin";
  this->getHp() = 110;
  this->getAtk() = 15;
  this->getDef() = 20;
  maxHP = this->getHp();
}

// void Goblin::attack(Character* opposite) {
//   int damage = ceil((100 / (100 + opposite->def)) * this->atk);
//   if(opposite->race != "halfling") {
//   	opposite->beAttack(this);
//   } else {
//   	srand((unsigned)time(NULL));
//   	int r = rand() % 2;
//   	if(r == 1) {// 0 miss 1 hit
//   	  opposite->beAttack(this);
//   	}
//   }
//   if(opposite->hp = 0) gold += 5;
// }
//
// void Goblin::beAttack(Character* opposite) {
//   int damage = ceil((100 / (100 + this->def)) * opposite->atk);
//   if(opposite->race == "elf") {
//     damage *= 2;
//   }
//   if(opposite->race == "orcs") {
//   	damage *= 1.5;
//   }
//   (damage >= this->hp) ? (this->hp = 0) : (this->hp -= damage);
//   if(this->hp == 0) this->isDead();
// }

Goblin::~Goblin() {}
