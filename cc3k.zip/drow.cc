#include "drow.h"
#include <cmath>

Drow::Drow():Player{} {
  this->getRace() = "Drow";
  this->getHp() = 155;
  this->getAtk() = 25;
  this->getDef() = 15;
  maxHP = this->getHp();
}
Drow::~Drow(){}
//void Drow::beAttack(Character* opposite) {
//  int damage = ceil((100 / (100 + this->def)) * opposite->atk);
//  (damage >= this->hp) ? (this->hp = 0) : (this->hp -= damage);
//  if(this->hp == 0) this->isDead();
//}

//void Drow::attack(Character * whom){
//		whom -> beAttacked(this);
//}
