#ifndef __CHARACTER_H__
#define __CHARACTER_H__
#include <utility>
#include <iostream>
#include <string>

class Character {
  std::string race;
  int hp;
  int atk;
  int def;
  int gold;
  bool permission;
  bool state; // true -> it used to attack merchant
public:
  Character();
  int &getDef();
  int &getAtk();
  int &getHp();
  int &getGold();
  virtual int &getMax();
  virtual bool &getPermiss();
  bool &getState();
  virtual bool isE();
  std::string &getRace();
  bool isDead();
  virtual void printInfo();

  virtual int attack(Character *whom);
  virtual int beAttacked(Character *who);
  virtual std::string setApply();
  

  virtual ~Character() = 0;

  friend std::ostream &operator<<(std::ostream &out, Character &c);
};

#endif
