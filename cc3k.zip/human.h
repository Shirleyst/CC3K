#ifndef __HUMAN_H__
#define __HUMAN_H__
#include <utility>
#include "enemy.h"

class Human: public Enemy{
	//Human();
	public:
		Human();
		~Human();
};


#endif
