#include "player.h"

class Goblin : public Player {
public:
  Goblin();
  //virtual void attack(Character* opposite) override;
  //virtual void beAttack(Character* opposite) override;
  ~Goblin();
};
