#include "halfling.h"
#include <string>
using namespace std;


Halfling::Halfling():Enemy{} {
	getHp() = 100;
	getAtk() = 15;
	getDef() = 20;
	getRace() = "Halfling";
}

Halfling::~Halfling(){}
