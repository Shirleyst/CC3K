#include "player.h"

class Vampire : public Player {
public:
  Vampire();
  //virtual void attack(Character* opposite) override;
  //virtual void beAttack(Character* opposite) override;
  ~Vampire();
};
