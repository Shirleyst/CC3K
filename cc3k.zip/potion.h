// #include "decorator.h"

// class Character;

// class Potion: public Decorator {
//  public:
//     Potion();
//  	Potion(Character *c, int type);
// };
