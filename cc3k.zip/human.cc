#include "human.h"
#include <string>

using namespace std;

Human::Human(): Enemy{} {
	getHp() = 140;
	getAtk() = 20;
	getDef() = 20;
	getRace() = "Human";
}

Human::~Human(){}
