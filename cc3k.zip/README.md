update: attack加上了，prinf information需要再测试（可能会print不全？感觉还好）
		龙的攻击没搞（其他都全了，各种特效需要再测试）
		药水有问题 第一遍可能用不上？
		怪物死掉掉金币没搞（金币想要简单一点可以直接加不用掉）
	    换楼层没搞
	    指令里面的r restart没有搞
	    smart_ptr全部没搞 <- 现在memory leak
	    fn最后要理，现在太乱了
		还要用valgrind查error <- segmentation的问题要查



push用：
（按顺序用这三个）
git add <filename> // git add *          update all files in current dir
git commit -m "Commit message"  // message可以随便改
git push origin master          // push到master分支上 
					            // 也可以 git push origin <branchname> push到其他分支上
					            // 防止push上去的东西有问题又已经把原来master的覆盖掉

pull用：
git pull

建branch(1+2)：
1.git checkout -b <name> // 建branch 同时切换到此branch
2.git push origin <branch> 

git checkout master // 切回master
git branch -d <name> // delete branch

replace local file with remote one:
git checkout -- <filename>
