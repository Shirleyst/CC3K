#include "elf.h"
#include <string>
using namespace std;


Elf::Elf(): Enemy{} {
	getHp() = 140;
	getAtk() = 30;
	getDef() = 10;
	getRace() = "Elf";
}

Elf::~Elf(){}
