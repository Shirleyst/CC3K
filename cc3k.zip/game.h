#ifndef GAME_H
#define GAME_H
#include <vector>
#include <string>
//#include "floor.h"

class Floor;
class Cell;
class Character;

class Game {
protected:
  std::string command;
  Floor* floors;
  std::vector <std::vector <Cell>> base;
  std::vector <Cell> emptys;
  std::string race;
  int numFloors;
  int currentFloor;
public:
  Game();
  void generate(int hp = 0);
  void move(std::string &comm);
  void use(std::string &comm);
  void attack(std::string &comm);
  void stop();
  std::vector <Cell> getEmp();
  std::vector <std::vector <Cell>> getBase();
  void nextlevel(int hp = 0);
  bool isWin();
  bool isLost();

  void checkChamber();
  void checkSurround(Cell &middle, int chamber, int r_l, int c_l);
  ~Game();

  friend std::istream &operator>>(std::istream &in, Game &g);
  friend std::ostream &operator<<(std::ostream &out, Game &g);
};


#endif
