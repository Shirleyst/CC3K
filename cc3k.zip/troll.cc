#include "troll.h"

Troll::Troll():Player{} {
  this->getRace() = "Troll";
  this->getHp() = 120;
  this->getAtk() = 25;
  this->getDef() = 15;
  maxHP = this->getHp();
}

Troll::~Troll() { // every turn regains 5 HP???<-three question marks so kawaii!!
}
