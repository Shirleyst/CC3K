#include "player.h"
#include <utility>
#include <cstdlib>
#include <iostream>
#include <ctime>
#include <cmath>

using namespace std;

Player::Player(): Character{}, maxHP{0} {}

int &Player::getMax() {return maxHP;}
int Player::attack(Character* whom) {
	int damage = 0;
	if(whom->getRace() != "Halfling") { // 100% hit
		damage += whom->beAttacked(this);
		if(this->getRace()=="Vampire"){
			if(whom->getRace() =="Dwarf"){
				this->getHp() -= 5;
			} else {
				this->getHp() += 5;
			}
		}
	} else { // there is 1/2 chance to miss
		srand(clock());
		int r = rand() % 2;
		if(r == 1) { // 0 miss 1 hit
			damage += whom->beAttacked(this);
		}
	}
	return damage;
}


int Player::beAttacked(Character* who) {
	int damage = ceil(who->getAtk() * 100 / (100 + this->getDef()));
	if((this->getRace() == "Goblin") && (who->getRace() =="Orcs")){
		damage *= 1.5;
	}
	if(getHp() > damage){
		getHp() -= damage;
	} else {
		getHp() = 0;
	}
	return damage;
}

void Player::printInfo() {
  cout << "HP: " << getHp() << endl;
  cout << "Atk: " << getAtk() << endl;
  cout << "Def: " << getDef() << endl;
  cout << "Action: ";
}

Player::~Player() {}
