#include "decorator.h"

class Character;

class Item: public Decorator {
 public:
    //Item();
 	Item(Character *c, std::string race, int type);
};