// #include "gold.h"
// #include "cell.h"

// using namespace std;

// Gold::Gold(): Decorator{nullptr} {this->getRace() = "Gold";}

// Gold::Gold(Character *c, string type): Decorator{c} {
//   this->getRace() = "Gold";
//   this->getGold() = 0;
//   if(type == "normal") this->getGold() = 2;
//   if(type == "dragon") this->getGold() = 6;
//   if(type == "small") this->getGold() = 1;
// }
