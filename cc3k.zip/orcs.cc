#include "orcs.h"
#include <string>
using namespace std;


Orcs::Orcs(){
	//this->coord = coord;
	getHp() = 180;
	getAtk() = 30;
	getDef() = 25;
	getRace() = "Orcs";
}

Orcs::~Orcs(){}
