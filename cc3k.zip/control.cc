#include "control.h"
#include "game.h"

Control::Control(game *g): g{g}, c{""} {}

void Control::command(string &comm) {
  c = comm;
  game->control(comm);
}


// void Control::cin_command(){
//   string command;
//   while(cin >> command){
//     if(command == "so") {
//       g->move_player("so");
//     }
//     if(command == "no") {
//       g->move_north();
//     }
//     if(command == "ea") {
//       g->move_east();
//     }
//     if(command == "we") {
//       g->move_west();
//     }
//     if(command == "se") {
//       g->move_south_east();
//     }
//     if(command == "sw") {
//       g->move_south_west());
//     }
//     if(command == "ne") {
//       g->move_north_east();
//     }
//     if(command == "nw") {
//       g->move_north_west();
//     }
//     if(command == "a"){
//       string dir;
//       cin >> dir;
//       g->attack(dir);
//     }
//   }
// }

Control::~Control() { delete game; }
