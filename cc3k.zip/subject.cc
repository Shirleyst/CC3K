#include "subject.h"
#include "observer.h"
#include <algorithm>
#include <string>

using namespace std;

// Subject::attach(o) puts o to the end of the observers
void Subject::attach(Observer *o) {
  if (std::binary_search(observers.begin(), observers.end(), o)) return;
  observers.push_back(o);
  sort(observers.begin(), observers.end());
}

void Subject::dettach(Observer *o){
  observers.erase(std::remove(observers.begin(), observers.end(), o), observers.end());
}


// Subject::notifyObservers(t) notifies all members in observers which have
//   subscription type t
string Subject::notifyObservers(Floor &f, pair<int,int> coo, Subject &) {
  string info{};
  for(auto it = observers.begin(); it != observers.end(); ++it) {
  	string add = (*it)->notify(f, coo, *this);
  	if(add != "") {info += " " + add;}
  }
  return info;
}

vector<Observer*> &Subject::getOb() {
  return observers;
}

void Subject::clearOb() {
  observers.clear();
}

// dtor
Subject::~Subject() {};
